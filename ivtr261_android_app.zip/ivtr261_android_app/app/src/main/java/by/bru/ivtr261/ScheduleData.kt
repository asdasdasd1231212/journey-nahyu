package by.bru.ivtr261

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class BellSlot(val num: Int, val start: LocalTime, val end: LocalTime)

data class Lesson(
    val pairNum: Int,
    val subject: String,
    val teacher: String,
    val room: String,
    val type: String
)

data class LiveStatus(
    val week: Int,
    val current: Lesson?,
    val currentBell: BellSlot?,
    val next: Lesson?,
    val nextBell: BellSlot?,
    val progressPercent: Int,
    val remainingMinutes: Long,
    val minutesUntilNext: Long,
    val todayLessons: List<Pair<BellSlot, Lesson>>
)

object ScheduleData {
    val ZONE_MINSK: ZoneId = ZoneId.of("Europe/Minsk")

    val BELLS = listOf(
        BellSlot(1, LocalTime.of(8, 30), LocalTime.of(10, 5)),
        BellSlot(2, LocalTime.of(10, 25), LocalTime.of(12, 0)),
        BellSlot(3, LocalTime.of(12, 30), LocalTime.of(14, 5)),
        BellSlot(4, LocalTime.of(14, 20), LocalTime.of(15, 55)),
        BellSlot(5, LocalTime.of(16, 5), LocalTime.of(17, 40)),
        BellSlot(6, LocalTime.of(17, 50), LocalTime.of(19, 25)),
        BellSlot(7, LocalTime.of(19, 35), LocalTime.of(21, 10))
    )

    private val week1: Map<DayOfWeek, List<Lesson>> = mapOf(
        DayOfWeek.MONDAY to listOf(
            Lesson(1, "Элективные курсы по физической культуре и спорту", "Малышева Е.А", "1 корп., Спортивный зал", "Физкультура"),
            Lesson(2, "Программирование", "Сергиенко О.В", "2 корп., ауд. 502", "Лекция"),
            Lesson(3, "Программирование", "Сергиенко О.В", "2 корп., ауд. 517", "Лабораторная")
        ),
        DayOfWeek.TUESDAY to listOf(
            Lesson(1, "Информатика", "Кутузов В.В", "2 корп., ауд. 517", "Лабораторная"),
            Lesson(2, "Основы российской государственности", "Попелышко Д.М", "1 корп., ауд. 534", "Практика"),
            Lesson(3, "Информационный час", "Шемякова С.Н", "2 корп., ауд. 512", "Информ. час")
        ),
        DayOfWeek.WEDNESDAY to listOf(
            Lesson(1, "Математика", "Бутома А.М", "1 корп., ауд. 407", "Практика"),
            Lesson(2, "История России", "Цумарева Е.П", "1 корп., ауд. 301", "Лекция"),
            Lesson(3, "Математика", "Орлова Т.Ю", "1 корп., ауд. 530", "Лекция"),
            Lesson(4, "История России", "Чернов С.В", "1 корп., ауд. 549", "Практика")
        ),
        DayOfWeek.THURSDAY to listOf(
            Lesson(1, "Информатика", "Кутузов В.В", "2 корп., ауд. 502", "Лекция"),
            Lesson(2, "Элективные курсы по физической культуре и спорту", "Малышева Е.А", "1 корп., Спортивный зал", "Физкультура"),
            Lesson(3, "Теория алгоритмов", "Беккер И.А", "1 корп., ауд. 231", "Лабораторная")
        ),
        DayOfWeek.FRIDAY to listOf(
            Lesson(2, "Математика", "Бутома А.М", "1 корп., ауд. 534", "Практика"),
            Lesson(3, "Иностранный язык", "Балабанов В.Б", "1 корп., ауд. 513", "Практика")
        )
    )

    private val week2: Map<DayOfWeek, List<Lesson>> = mapOf(
        DayOfWeek.MONDAY to listOf(
            Lesson(1, "Элективные курсы по физической культуре и спорту", "Малышева Е.А", "1 корп., Спортивный зал", "Физкультура"),
            Lesson(2, "Программирование", "Сергиенко О.В", "2 корп., ауд. 502", "Лекция"),
            Lesson(3, "Программирование", "Сергиенко О.В", "2 корп., ауд. 517", "Лабораторная"),
            Lesson(4, "Теория алгоритмов", "Беккер И.А", "1 корп., ауд. 237", "Лекция")
        ),
        DayOfWeek.TUESDAY to listOf(
            Lesson(1, "Информатика", "Кутузов В.В", "2 корп., ауд. 517", "Лабораторная"),
            Lesson(2, "Основы российской государственности", "Попелышко Д.М", "1 корп., ауд. 534", "Практика"),
            Lesson(3, "Университетоведение", "Минченя Е.А", "1 корп., ауд. 301", "Лекция")
        ),
        DayOfWeek.WEDNESDAY to listOf(
            Lesson(2, "История России", "Цумарева Е.П", "1 корп., ауд. 301", "Лекция"),
            Lesson(3, "Математика", "Орлова Т.Ю", "1 корп., ауд. 530", "Лекция"),
            Lesson(4, "История России", "Чернов С.В", "1 корп., ауд. 549", "Практика")
        ),
        DayOfWeek.THURSDAY to listOf(
            Lesson(1, "Информатика", "Кутузов В.В", "2 корп., ауд. 502", "Лекция"),
            Lesson(2, "Элективные курсы по физической культуре и спорту", "Малышева Е.А", "1 корп., Спортивный зал", "Физкультура"),
            Lesson(3, "Деловая коммуникация и тайм-менеджмент", "Комарова С.Л", "1 корп., ауд. 534", "Практика"),
            Lesson(4, "Деловая коммуникация и тайм-менеджмент", "Комарова С.Л", "1 корп., ауд. 530", "Лекция")
        ),
        DayOfWeek.FRIDAY to listOf(
            Lesson(1, "Основы российской государственности", "Попелышко Д.М", "1 корп., ауд. 301", "Лекция"),
            Lesson(2, "Математика", "Бутома А.М", "1 корп., ауд. 534", "Практика"),
            Lesson(3, "Иностранный язык", "Балабанов В.Б", "1 корп., ауд. 513", "Практика"),
            Lesson(4, "Информационный час", "Шемякова С.Н", "1 корп., ауд. 142", "Информ. час")
        )
    )

    fun detectWeek(date: LocalDate, weekOverride: Int): Int {
        if (weekOverride == 1 || weekOverride == 2) return weekOverride
        val anchor = LocalDate.of(2026, 10, 19)
        val weeks = ChronoUnit.WEEKS.between(anchor, date)
        return if (((weeks % 2) + 2) % 2 == 0L) 1 else 2
    }

    fun getLessonsForDay(week: Int, day: DayOfWeek): List<Pair<BellSlot, Lesson>> {
        val map = if (week == 1) week1 else week2
        val list = map[day].orEmpty()
        return list.mapNotNull { lesson ->
            val bell = BELLS.find { it.num == lesson.pairNum }
            if (bell != null) bell to lesson else null
        }.sortedBy { it.first.num }
    }

    fun computeLiveStatus(weekOverride: Int): LiveStatus {
        val nowDate = LocalDate.now(ZONE_MINSK)
        val nowTime = LocalTime.now(ZONE_MINSK)
        val week = detectWeek(nowDate, weekOverride)
        val todayLessons = getLessonsForDay(week, nowDate.dayOfWeek)

        val currentPair = todayLessons.find { (bell, _) ->
            !nowTime.isBefore(bell.start) && nowTime.isBefore(bell.end)
        }
        val nextPair = todayLessons.find { (bell, _) ->
            bell.start.isAfter(nowTime)
        }

        var progress = 0
        var remaining = 0L
        if (currentPair != null) {
            val totalSec = ChronoUnit.SECONDS.between(currentPair.first.start, currentPair.first.end).coerceAtLeast(1)
            val elapsedSec = ChronoUnit.SECONDS.between(currentPair.first.start, nowTime).coerceIn(0, totalSec)
            progress = ((elapsedSec * 100) / totalSec).toInt()
            remaining = ChronoUnit.MINUTES.between(nowTime, currentPair.first.end).coerceAtLeast(0) + 1
        }

        val minsUntilNext = if (nextPair != null) {
            ChronoUnit.MINUTES.between(nowTime, nextPair.first.start).coerceAtLeast(0)
        } else 0L

        return LiveStatus(
            week = week,
            current = currentPair?.second,
            currentBell = currentPair?.first,
            next = nextPair?.second,
            nextBell = nextPair?.first,
            progressPercent = progress,
            remainingMinutes = remaining,
            minutesUntilNext = minsUntilNext,
            todayLessons = todayLessons
        )
    }
}
