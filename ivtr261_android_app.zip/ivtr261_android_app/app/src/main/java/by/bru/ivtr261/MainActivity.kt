package by.bru.ivtr261

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val uiTicker = object : Runnable {
        override fun run() {
            refreshUI()
            handler.postDelayed(this, 5000L)
        }
    }

    private val requestPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startOngoingService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences(ScheduleForegroundService.PREFS_NAME, Context.MODE_PRIVATE)

        findViewById<Button>(R.id.btnStartService).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                startOngoingService()
            }
        }

        findViewById<Button>(R.id.btnStopService).setOnClickListener {
            prefs.edit().putBoolean("service_enabled", false).apply()
            stopService(Intent(this, ScheduleForegroundService::class.java))
            refreshUI()
        }

        val chk15 = findViewById<CheckBox>(R.id.chk15)
        val chk5 = findViewById<CheckBox>(R.id.chk5)
        val chk0 = findViewById<CheckBox>(R.id.chk0)
        chk15.isChecked = prefs.getBoolean("remind_15", true)
        chk5.isChecked = prefs.getBoolean("remind_5", true)
        chk0.isChecked = prefs.getBoolean("remind_0", true)

        chk15.setOnCheckedChangeListener { _, isChecked -> prefs.edit().putBoolean("remind_15", isChecked).apply() }
        chk5.setOnCheckedChangeListener { _, isChecked -> prefs.edit().putBoolean("remind_5", isChecked).apply() }
        chk0.setOnCheckedChangeListener { _, isChecked -> prefs.edit().putBoolean("remind_0", isChecked).apply() }

        val rgWeek = findViewById<RadioGroup>(R.id.rgWeek)
        when (prefs.getInt("week_override", 0)) {
            1 -> findViewById<RadioButton>(R.id.rbWeek1).isChecked = true
            2 -> findViewById<RadioButton>(R.id.rbWeek2).isChecked = true
            else -> findViewById<RadioButton>(R.id.rbAuto).isChecked = true
        }
        rgWeek.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.rbWeek1 -> 1
                R.id.rbWeek2 -> 2
                else -> 0
            }
            prefs.edit().putInt("week_override", mode).apply()
            refreshUI()
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(uiTicker)
    }

    override fun onPause() {
        handler.removeCallbacks(uiTicker)
        super.onPause()
    }

    private fun startOngoingService() {
        val prefs = getSharedPreferences(ScheduleForegroundService.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean("service_enabled", true).apply()
        ContextCompat.startForegroundService(this, Intent(this, ScheduleForegroundService::class.java))
        refreshUI()
    }

    private fun refreshUI() {
        val prefs = getSharedPreferences(ScheduleForegroundService.PREFS_NAME, Context.MODE_PRIVATE)
        val weekOverride = prefs.getInt("week_override", 0)
        val status = ScheduleData.computeLiveStatus(weekOverride)

        findViewById<TextView>(R.id.tvWeekInfo).text = "ИВТР-261 · Неделя ${status.week}"
        val tvCurrent = findViewById<TextView>(R.id.tvCurrent)
        val tvNext = findViewById<TextView>(R.id.tvNext)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        if (status.current != null && status.currentBell != null) {
            val c = status.current
            tvCurrent.text = "Сейчас (${c.pairNum} пара, ${status.currentBell.start}–${status.currentBell.end}):\n${c.subject}\n📍 ${c.room} · ${c.teacher}\nОсталось: ${status.remainingMinutes} мин (${status.progressPercent}%)"
            progressBar.progress = status.progressPercent
        } else {
            tvCurrent.text = if (status.next != null) "Сейчас перемена / свободное время" else "На сегодня пар нет"
            progressBar.progress = 0
        }

        tvNext.text = if (status.next != null && status.nextBell != null) {
            val n = status.next
            "Следующая через ${status.minutesUntilNext} мин (${status.nextBell.start}):\n${n.subject}\n📍 ${n.room} (${n.type})"
        } else {
            "Следующих пар сегодня нет"
        }

        val todayStr = if (status.todayLessons.isEmpty()) {
            "Сегодня занятий нет"
        } else {
            status.todayLessons.joinToString("\n\n") { (bell, l) ->
                "${l.pairNum}. ${bell.start}–${bell.end} · ${l.subject}\n   📍 ${l.room} (${l.type})"
            }
        }
        findViewById<TextView>(R.id.tvTodayList).text = todayStr
    }
}
