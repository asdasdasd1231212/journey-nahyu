package by.bru.ivtr261

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.time.LocalDate

class ScheduleForegroundService : Service() {

    companion object {
        const val CHANNEL_ONGOING = "ivtr261_ongoing"
        const val CHANNEL_ALERTS = "ivtr261_alerts"
        const val NOTIF_ID_ONGOING = 26101
        const val PREFS_NAME = "ivtr261_prefs"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val firedKeys = mutableSetOf<String>()

    private val ticker = object : Runnable {
        override fun run() {
            updateOngoingNotification()
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID_ONGOING, buildOngoingNotification())
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ongoing = NotificationChannel(
                CHANNEL_ONGOING,
                "Текущая пара (постоянное)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Постоянное уведомление с прогрессом пары и следующей парой"
                setShowBadge(false)
            }
            val alerts = NotificationChannel(
                CHANNEL_ALERTS,
                "Напоминания о парах",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Звуковые напоминания за 15, 5 минут и к началу пары"
            }
            nm.createNotificationChannel(ongoing)
            nm.createNotificationChannel(alerts)
        }
    }

    private fun updateOngoingNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID_ONGOING, buildOngoingNotification())
    }

    private fun buildOngoingNotification(): Notification {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val weekOverride = prefs.getInt("week_override", 0)
        val status = ScheduleData.computeLiveStatus(weekOverride)

        checkAlerts(status, prefs.getBoolean("remind_15", true), prefs.getBoolean("remind_5", true), prefs.getBoolean("remind_0", true))

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title: String
        val shortText: String
        val bigText: String
        val showProgress: Boolean

        if (status.current != null && status.currentBell != null) {
            val cur = status.current
            title = "${cur.subject} · ${cur.room}"
            shortText = "Осталось ${status.remainingMinutes} мин (до ${status.currentBell.end})"
            val nextPart = if (status.next != null && status.nextBell != null) {
                "\nДалее (${status.nextBell.start}): ${status.next.subject} — ${status.next.room}"
            } else {
                "\nПосле этой пары занятий больше нет"
            }
            bigText = "${cur.type} · ${cur.teacher}\nОсталось: ${status.remainingMinutes} мин (до ${status.currentBell.end})$nextPart"
            showProgress = true
        } else if (status.next != null && status.nextBell != null) {
            val nxt = status.next
            title = "Далее (${status.nextBell.start}): ${nxt.subject}"
            shortText = "Через ${status.minutesUntilNext} мин · ${nxt.room}"
            bigText = "Через ${status.minutesUntilNext} мин (${status.nextBell.start}–${status.nextBell.end})\n📍 ${nxt.room} · ${nxt.type}"
            showProgress = false
        } else {
            title = "ИВТР-261 · На сегодня пар нет"
            shortText = "Неделя ${status.week} · Свободное время"
            bigText = "Все занятия на сегодня завершены. Отличного дня!"
            showProgress = false
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ONGOING)
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle(title)
            .setContentText(shortText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        if (showProgress) {
            builder.setProgress(100, status.progressPercent, false)
        } else {
            builder.setProgress(0, 0, false)
        }

        return builder.build()
    }

    private fun checkAlerts(status: LiveStatus, r15: Boolean, r5: Boolean, r0: Boolean) {
        val todayStr = LocalDate.now(ScheduleData.ZONE_MINSK).toString()
        val nxt = status.next
        val nxtBell = status.nextBell
        if (nxt != null && nxtBell != null) {
            if (r15 && status.minutesUntilNext == 15L) {
                fireAlertOnce("$todayStr-${nxt.pairNum}-15", "Через 15 мин: ${nxt.subject}", "📍 ${nxt.room} · ${nxtBell.start}")
            }
            if (r5 && status.minutesUntilNext == 5L) {
                fireAlertOnce("$todayStr-${nxt.pairNum}-5", "Через 5 мин: ${nxt.subject}", "📍 ${nxt.room} · Пора в аудиторию")
            }
        }
        val cur = status.current
        if (r0 && cur != null && status.progressPercent <= 2) {
            val nextTxt = if (nxt != null && nxtBell != null) "\nДалее: ${nxt.subject} (${nxt.room} в ${nxtBell.start})" else ""
            fireAlertOnce("$todayStr-${cur.pairNum}-0", "Началась ${cur.pairNum} пара: ${cur.subject}", "📍 ${cur.room}$nextTxt")
        }
    }

    private fun fireAlertOnce(key: String, title: String, body: String) {
        if (!firedKeys.add(key)) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, CHANNEL_ALERTS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        nm.notify(key.hashCode(), notif)
    }
}
