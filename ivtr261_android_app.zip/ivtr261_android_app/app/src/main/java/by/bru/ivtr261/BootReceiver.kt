package by.bru.ivtr261

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences(ScheduleForegroundService.PREFS_NAME, Context.MODE_PRIVATE)
            if (prefs.getBoolean("service_enabled", false)) {
                ContextCompat.startForegroundService(context, Intent(context, ScheduleForegroundService::class.java))
            }
        }
    }
}
