package by.bru.ivtr261

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.time.DayOfWeek
import java.time.LocalDate

class FullScheduleActivity : AppCompatActivity() {

    private var selectedWeek = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_schedule)

        selectedWeek = ScheduleData.detectWeek(LocalDate.now(ScheduleData.ZONE_MINSK), 0)

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnTabWeek1).setOnClickListener {
            selectedWeek = 1
            renderSchedule()
        }
        findViewById<Button>(R.id.btnTabWeek2).setOnClickListener {
            selectedWeek = 2
            renderSchedule()
        }

        renderSchedule()
    }

    private fun renderSchedule() {
        findViewById<TextView>(R.id.tvFullTitle).text = "Полное расписание · Неделя $selectedWeek"
        val days = listOf(
            DayOfWeek.MONDAY,
            DayOfWeek.TUESDAY,
            DayOfWeek.WEDNESDAY,
            DayOfWeek.THURSDAY,
            DayOfWeek.FRIDAY,
            DayOfWeek.SATURDAY
        )

        val sb = StringBuilder()
        for (day in days) {
            val dayName = ScheduleData.DAY_NAMES[day] ?: ""
            val lessons = ScheduleData.getLessonsForDay(selectedWeek, day)
            sb.append("━━ ").append(dayName.uppercase()).append(" ━━\n")
            if (lessons.isEmpty()) {
                sb.append("Пар нет\n\n")
            } else {
                for ((bell, l) in lessons) {
                    sb.append("${l.pairNum}. ${bell.start}–${bell.end} · ${l.subject}\n")
                    sb.append("   📍 ${l.room} · ${l.type} (${l.teacher})\n\n")
                }
            }
        }
        findViewById<TextView>(R.id.tvFullContent).text = sb.toString().trim()
    }
}
